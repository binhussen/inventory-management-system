import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-finance-detail',
  templateUrl: './finance-detail.component.html',
  styleUrls: ['./finance-detail.component.scss']
})
export class FinanceDetailComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
