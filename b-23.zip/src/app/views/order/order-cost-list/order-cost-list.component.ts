import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-order-cost-list',
  templateUrl: './order-cost-list.component.html',
  styleUrls: ['./order-cost-list.component.scss']
})
export class OrderCostListComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
