export interface multipleSelectorModel{
    key: number;
    value: string;
}
