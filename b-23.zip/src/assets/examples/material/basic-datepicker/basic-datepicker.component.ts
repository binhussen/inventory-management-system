import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-basic-datepicker',
  templateUrl: './basic-datepicker.component.html',
  styleUrls: ['./basic-datepicker.component.scss']
})
export class BasicDatepickerComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
