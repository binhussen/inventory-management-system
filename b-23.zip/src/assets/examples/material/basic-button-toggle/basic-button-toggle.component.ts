import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-basic-button-toggle',
  templateUrl: './basic-button-toggle.component.html',
  styleUrls: ['./basic-button-toggle.component.scss']
})
export class BasicButtonToggleComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
