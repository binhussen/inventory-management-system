import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-request-edit',
  templateUrl: './request-edit.component.html',
  styleUrls: ['./request-edit.component.scss']
})
export class RequestEditComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
