import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-mat-kits',
  templateUrl: './mat-kits.component.html',
  styleUrls: ['./mat-kits.component.scss']
})
export class MatKitsComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
