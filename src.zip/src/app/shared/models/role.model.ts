export class Role {
  userId: string;
  role: string;
}
